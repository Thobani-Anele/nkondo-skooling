// Enhancements: theme toggle, mobile nav, year injection, small assistant placeholder.
// Merge with any existing script.js if needed.

(function () {
  const themeToggle = document.getElementById('theme-toggle');
  const mobileToggle = document.getElementById('mobile-nav-toggle');
  const mainNav = document.getElementById('main-nav');

  // Apply persisted theme
  const root = document.documentElement;
  const savedTheme = localStorage.getItem('nk-theme');
  if (savedTheme === 'light') root.classList.add('light');

  // Theme toggle behavior
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isLight = root.classList.toggle('light');
      localStorage.setItem('nk-theme', isLight ? 'light' : 'dark');
      themeToggle.textContent = isLight ? '🌤️' : '🌙';
    });
  }

  // Mobile nav toggle
  if (mobileToggle && mainNav) {
    mobileToggle.addEventListener('click', () => {
      mainNav.style.display = mainNav.style.display === 'flex' ? 'none' : 'flex';
    });
  }

  // Inject current year in footer(s)
  const year = new Date().getFullYear();
  document.querySelectorAll('#year, #year2, #year3').forEach(el => {
    if (el) el.textContent = year;
  });

  // Assistant widget
  const chatOpenBtn = document.getElementById('nk-chat-open');
  const chatModal = document.getElementById('nk-chat-modal');
  const chatCloseBtn = document.getElementById('nk-chat-close');
  const chatSendBtn = document.getElementById('nk-send');
  const chatInput = document.getElementById('nk-input');
  const messages = document.getElementById('nk-messages');

  function openChat(){
    if (chatModal) chatModal.setAttribute('aria-hidden','false');
  }
  function closeChat(){
    if (chatModal) chatModal.setAttribute('aria-hidden','true');
  }
  if (chatOpenBtn) chatOpenBtn.addEventListener('click', openChat);
  if (chatCloseBtn) chatCloseBtn.addEventListener('click', closeChat);

  if (chatSendBtn && chatInput && messages) {
    chatSendBtn.addEventListener('click', async () => {
      const text = chatInput.value && chatInput.value.trim();
      if (!text) return;
      appendMessage('You', text);
      chatInput.value = '';

      appendMessage('Assistant', 'Thinking...');
      // TODO: Replace this section with a call to your secure backend that proxies to OpenAI (or other model).
      try {
        await new Promise(r => setTimeout(r, 700)); // placeholder delay
        const thinking = messages.querySelector('.message.assistant.thinking');
        if (thinking) thinking.remove();
        appendMessage('Assistant', 'Placeholder reply — connect to your backend to get real responses.');
      } catch (err) {
        console.error(err);
        appendMessage('Assistant', 'Sorry, something went wrong.');
      }
    });
  }

  function appendMessage(author, text){
    const el = document.createElement('div');
    el.className = 'message ' + (author === 'Assistant' ? 'assistant' : 'user');
    if (author === 'Assistant' && text === 'Thinking...') el.classList.add('thinking');
    el.innerHTML = '<strong>' + escapeHtml(author) + ':</strong> <div>' + escapeHtml(text) + '</div>';
    if (messages) {
      messages.appendChild(el);
      messages.scrollTop = messages.scrollHeight;
    }
  }
  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]); }

  // keyboard shortcut
  window.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 't') {
      if (themeToggle) themeToggle.click();
    }
  });

})();