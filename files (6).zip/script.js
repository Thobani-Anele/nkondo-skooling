// Enhancements: Theme toggle, mobile nav, year injection, assistant placeholder,
// AND converted notebook to dynamic initializer (no reload). Multiple notebook
// elements (inline or modal) share the same per-room storage and stay in sync.
//
// Usage:
// - Inline notebook: <div class="notebook" data-room-id="room-id">...</div>
//   The manager will auto-init any .notebook on page load.
// - Modal notebook: put a .notebook inside the modal (it can be empty). Call
//   NotebookManager.openModal(roomId, modalElement) or use the helper listeners
//   below which wire buttons with `.open-notebook` and `data-room`.
(function () {
  /* ----------------------------- Basic UI ------------------------------ */
  const root = document.documentElement;
  const themeToggle = document.getElementById('theme-toggle');
  const mobileToggle = document.getElementById('mobile-nav-toggle');
  const mainNav = document.getElementById('main-nav');

  const savedTheme = localStorage.getItem('nk-theme');
  if (savedTheme === 'light') root.classList.add('light');
  if (themeToggle) themeToggle.textContent = root.classList.contains('light') ? '🌤️' : '🌙';

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isLight = root.classList.toggle('light');
      localStorage.setItem('nk-theme', isLight ? 'light' : 'dark');
      themeToggle.textContent = isLight ? '🌤️' : '🌙';
    });
  }
  if (mobileToggle && mainNav) {
    mobileToggle.addEventListener('click', () => {
      mainNav.style.display = mainNav.style.display === 'flex' ? 'none' : 'flex';
    });
  }
  const year = new Date().getFullYear();
  document.querySelectorAll('#year, #year2, #year3').forEach(el => { if (el) el.textContent = year; });

  /* --------------------------- Assistant UI --------------------------- */
  const chatOpenBtn = document.getElementById('nk-chat-open');
  const chatModal = document.getElementById('nk-chat-modal');
  const chatCloseBtn = document.getElementById('nk-chat-close');
  const chatSendBtn = document.getElementById('nk-send');
  const chatInput = document.getElementById('nk-input');
  const messages = document.getElementById('nk-messages');

  function openChat(){ if (chatModal) chatModal.setAttribute('aria-hidden','false'); }
  function closeChat(){ if (chatModal) chatModal.setAttribute('aria-hidden','true'); }
  if (chatOpenBtn) chatOpenBtn.addEventListener('click', openChat);
  if (chatCloseBtn) chatCloseBtn.addEventListener('click', closeChat);

  if (chatSendBtn && chatInput && messages) {
    chatSendBtn.addEventListener('click', async () => {
      const text = (chatInput.value || '').trim();
      if (!text) return;
      appendMessage('You', text);
      chatInput.value = '';
      appendMessage('Assistant', 'Thinking...');
      try {
        await new Promise(r => setTimeout(r, 600));
        const thinking = messages.querySelector('.message.assistant.thinking');
        if (thinking) thinking.remove();
        appendMessage('Assistant', 'Placeholder reply — connect to your backend to get real responses.');
      } catch (err) {
        console.error(err);
        appendMessage('Assistant', 'Sorry, something went wrong.');
      }
    });
  }
  function appendMessage(author, text){
    if (!messages) return;
    const el = document.createElement('div');
    el.className = 'message ' + (author === 'Assistant' ? 'assistant' : 'user');
    if (author === 'Assistant' && text === 'Thinking...') el.classList.add('thinking');
    el.innerHTML = '<strong>' + escapeHtml(author) + ':</strong> <div>' + escapeHtml(text) + '</div>';
    messages.appendChild(el);
    messages.scrollTop = messages.scrollHeight;
  }
  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]); }

  /* ------------------------- Notebook Manager ------------------------- */
  const NOTE_PREFIX = 'nk-notes-';
  const NotebookManager = {
    instances: {}, // roomId -> Notebook

    // Initialize or re-bind a notebook element for a room
    getOrCreate(roomId, element) {
      if (!roomId) roomId = 'default';
      let inst = this.instances[roomId];
      if (inst) {
        if (element) inst.attachElement(element);
        return inst;
      }
      inst = new Notebook(roomId, element);
      this.instances[roomId] = inst;
      return inst;
    },

    // helper to open a modal with a notebook element inside it
    openModal(roomId, modalEl) {
      const nbEl = modalEl.querySelector('.notebook');
      if (!nbEl) {
        console.warn('Modal does not contain .notebook element');
        return;
      }
      nbEl.dataset.roomId = roomId;
      modalEl.setAttribute('aria-hidden','false');
      const inst = this.getOrCreate(roomId, nbEl);
      inst.focusEditor();
    },

    closeModal(modalEl) {
      modalEl.setAttribute('aria-hidden','true');
    }
  };

  function Notebook(roomId, element) {
    this.roomId = roomId || 'default';
    this.storageKey = NOTE_PREFIX + this.roomId;
    this.notes = [];
    this.activeId = null;
    this.root = null; // the DOM element currently bound
    if (element) this.attachElement(element);
    this.loadNotes();
  }

  Notebook.prototype.attachElement = function(el){
    // attach UI to a new root element (modal or inline)
    this.root = el;
    // find places for UI
    this.sidebar = el.querySelector('.notebook-sidebar') || el.querySelector('.notes-list');
    this.editor = el.querySelector('.notebook-editor');
    this.titleInput = el.querySelector('.note-title');
    this.newBtn = el.querySelector('.note-new');
    this.deleteBtn = el.querySelector('.note-delete');
    this.exportBtn = el.querySelector('.note-export');

    // ensure editor is contenteditable
    if (this.editor && !this.editor.isContentEditable) this.editor.setAttribute('contenteditable','true');

    // wire events
    this.bindUI();
    // re-render
    this.renderSidebar();
    // open current active (or first) note
    if (!this.activeId && this.notes.length) this.activeId = this.notes[0].id;
    this.openNote(this.activeId);
  };

  Notebook.prototype.loadNotes = function(){
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (!raw) {
        // create starter note
        this.notes = [{
          id: 'n1',
          title: 'Quick notes',
          content: 'Start your notes here. Everything is saved locally in your browser for this room.',
          updated: Date.now()
        }];
        this.activeId = 'n1';
        this.saveNotes();
      } else {
        this.notes = JSON.parse(raw) || [];
        this.activeId = this.notes.length ? this.notes[0].id : null;
      }
    } catch (e) {
      console.error('Failed to load notes for', this.storageKey, e);
      this.notes = [];
      this.activeId = null;
    }
  };

  Notebook.prototype.saveNotes = function(){
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.notes));
    } catch (e) {
      console.error('Failed to save notes', e);
    }
  };

  Notebook.prototype.renderSidebar = function(){
    if (!this.sidebar) return;
    // clear
    this.sidebar.innerHTML = '';
    // If this sidebar is a compact .notes-list (no controls), render only titles
    const isCompact = this.sidebar.classList.contains('notes-list');
    this.notes.forEach(n => {
      const node = document.createElement('div');
      node.className = 'note-item' + (n.id === this.activeId ? ' active':'' );
      node.dataset.id = n.id;
      node.textContent = n.title || 'Untitled';
      node.addEventListener('click', () => { this.openNote(n.id); });
      this.sidebar.appendChild(node);
    });

    // If sidebar is notebook-sidebar and there is a .notes-list inside it, also fill that
    const innerNotesList = this.root ? this.root.querySelector('.notes-list') : null;
    if (innerNotesList && innerNotesList !== this.sidebar) {
      innerNotesList.innerHTML = '';
      this.notes.forEach(n => {
        const node = document.createElement('div');
        node.className = 'note-item' + (n.id === this.activeId ? ' active':'' );
        node.dataset.id = n.id;
        node.textContent = n.title || 'Untitled';
        node.addEventListener('click', () => { this.openNote(n.id); });
        innerNotesList.appendChild(node);
      });
    }
  };

  Notebook.prototype.openNote = function(id){
    const n = this.notes.find(x => x.id === id);
    if (!n) return;
    this.activeId = n.id;
    if (this.titleInput) this.titleInput.value = n.title;
    if (this.editor) this.editor.innerHTML = n.content;
    this.renderSidebar();
    this.focusEditor();
  };

  Notebook.prototype.createNote = function(){
    const id = 'n' + Date.now();
    const note = { id, title: 'Untitled', content: '', updated: Date.now() };
    this.notes.unshift(note);
    this.activeId = id;
    this.saveNotes();
    this.renderSidebar();
    this.openNote(id);
  };

  Notebook.prototype.deleteActive = function(){
    if (!this.activeId) return;
    this.notes = this.notes.filter(n => n.id !== this.activeId);
    this.activeId = this.notes.length ? this.notes[0].id : null;
    this.saveNotes();
    this.renderSidebar();
    this.openNote(this.activeId);
  };

  Notebook.prototype.exportActive = function(){
    const n = this.notes.find(x => x.id === this.activeId);
    if (!n) return;
    const blob = new Blob([`# ${n.title}\n\n${n.content}`], {type:'text/markdown'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (n.title || 'note') + '.md';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  Notebook.prototype.bindUI = function(){
    const self = this;
    if (!this.editor) return;

    // Unbind previous if present to avoid duplicate listeners
    if (this._unbindEditor) this._unbindEditor();

    let saveTimer = null;
    const onEditorInput = () => {
      if (!self.activeId) return;
      const n = self.notes.find(x => x.id === self.activeId);
      if (!n) return;
      n.content = self.editor.innerHTML;
      n.updated = Date.now();
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => { self.saveNotes(); self.renderSidebar(); }, 600);
    };
    this.editor.addEventListener('input', onEditorInput);

    const onTitleInput = () => {
      if (!self.activeId || !self.titleInput) return;
      const n = self.notes.find(x => x.id === self.activeId);
      if (!n) return;
      n.title = self.titleInput.value;
      n.updated = Date.now();
      self.saveNotes();
      self.renderSidebar();
    };
    if (this.titleInput) this.titleInput.addEventListener('input', onTitleInput);

    if (this.newBtn) this.newBtn.addEventListener('click', () => self.createNote());
    if (this.deleteBtn) this.deleteBtn.addEventListener('click', () => {
      if (confirm('Delete this note?')) self.deleteActive();
    });
    if (this.exportBtn) this.exportBtn.addEventListener('click', () => self.exportActive());

    // allow cleanup
    this._unbindEditor = () => {
      this.editor.removeEventListener('input', onEditorInput);
      if (this.titleInput) this.titleInput.removeEventListener('input', onTitleInput);
    };
  };

  Notebook.prototype.focusEditor = function(){
    if (this.editor) {
      this.editor.focus();
      // place caret at end
      try {
        const range = document.createRange();
        range.selectNodeContents(this.editor);
        range.collapse(false);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      } catch (e) {}
    }
  };

  /* ---------------------- Auto-init inline notebooks --------------------- */
  document.querySelectorAll('.notebook').forEach(nEl => {
    const room = nEl.dataset.roomId || nEl.closest('[data-room-id]')?.dataset?.roomId || 'default';
    NotebookManager.getOrCreate(room, nEl);
  });

  /* ---------------------- Modal wiring for study-rooms ------------------ */
  // Wire open buttons with class .open-notebook and data-room attribute
  document.querySelectorAll('.open-notebook').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const room = btn.dataset.room || btn.getAttribute('data-room') || 'default';
      const modal = document.getElementById('notebook-modal');
      if (!modal) {
        // If page doesn't have a modal, try to find an inline anchor target by id
        const anchorId = btn.getAttribute('href')?.split('#')[1];
        if (anchorId) {
          const target = document.getElementById(anchorId);
          if (target) {
            // Ensure .notebook inside target has data-room-id set
            const nb = target.querySelector('.notebook');
            if (nb) {
              nb.dataset.roomId = room;
              NotebookManager.getOrCreate(room, nb);
              nb.scrollIntoView({behavior:'smooth'});
            }
          }
        }
        return;
      }
      const nbEl = modal.querySelector('.notebook');
      if (!nbEl) {
        console.warn('Please include a .notebook inside #notebook-modal');
        modal.setAttribute('aria-hidden','false');
        return;
      }
      // Dynamically attach the modal's notebook element to the room and show
      nbEl.dataset.roomId = room;
      NotebookManager.openModal(room, modal);
    });
  });

  // close modal
  const notebookClose = document.getElementById('notebook-close');
  const notebookModal = document.getElementById('notebook-modal');
  if (notebookClose && notebookModal) {
    notebookClose.addEventListener('click', () => NotebookManager.closeModal(notebookModal));
  }

  /* ----------------------------- Shortcuts ----------------------------- */
  window.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 't') { if (themeToggle) themeToggle.click(); }
    if (e.key.toLowerCase() === 'n') {
      // focus the first notebook editor if present
      const ed = document.querySelector('.notebook-editor[contenteditable="true"]');
      if (ed) ed.focus();
    }
  });

  // expose for debugging
  window.Nkondo = window.Nkondo || {};
  window.Nkondo.NotebookManager = NotebookManager;

})();